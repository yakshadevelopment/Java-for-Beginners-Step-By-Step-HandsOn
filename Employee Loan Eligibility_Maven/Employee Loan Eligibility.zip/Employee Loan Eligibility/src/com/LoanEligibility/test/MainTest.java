package com.LoanEligibility.test;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.Before;
import org.junit.jupiter.api.Test;

import com.LoanEligibility.Employee;
import com.LoanEligibility.Loan;
import com.LoanEligibility.PermanentEmployee;
import com.LoanEligibility.TemporaryEmployee;

class MainTest {

	
	 
	@Test
	void testCalculateLoanAmount() {
		Loan loan=new Loan();
		  Employee p=new PermanentEmployee(1, "Ritika", 50000);
		  Employee t=new TemporaryEmployee(56, "Sohan", 200, 100);
		  p.calculateSalary();
		  t.calculateSalary();
		double loanAmountP=loan.calculateLoanAmount(p);
				assertEquals(6600.0, loanAmountP);
				double loanAmountT=loan.calculateLoanAmount(t);
				assertEquals(2000.0, loanAmountT);
		  
	}
	
	@Test
	void testCalculateSalary() {
		
		Employee p=new PermanentEmployee(1, "Ritika", 50000);
		  Employee t=new TemporaryEmployee(56, "Sohan", 200, 100);
		  p.calculateSalary();
		  t.calculateSalary();
		  assertEquals(44000.0,p.getSalary());
		  assertEquals(20000.0,t.getSalary());
	}
	 
		
}
