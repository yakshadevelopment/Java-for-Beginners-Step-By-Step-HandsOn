package com.test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import com.java.PrimeNumbers;

class PrimeNumbersTest {

	@Test
	void testIsPrime() {
		 assertEquals(true, PrimeNumbers.isPrime(5));
		 assertEquals(false, PrimeNumbers.isPrime(8));
	}
	@Test
	void testPrimeNumberList() {
		assertEquals(true, PrimeNumbers.primeNumberList(2,15));
		 assertEquals(false, PrimeNumbers.primeNumberList(8,5));
		
	}

}
