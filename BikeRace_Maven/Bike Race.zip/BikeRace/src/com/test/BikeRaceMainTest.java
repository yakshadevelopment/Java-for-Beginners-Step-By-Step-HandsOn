package com.test;
import com.java.*;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

class BikeRaceMainTest {

	@Test
	void testFindBonusPoint() {
		
		BikeRace b=new BikeRace();
		assertEquals("Your bonus points is 72", b.findBonusPoint(8694));
		assertEquals("Invalid Input", b.findBonusPoint(-1));
	}

}
