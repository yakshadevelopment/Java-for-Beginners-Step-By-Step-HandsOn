

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MainTest {

	@Test
	void testTrackAssociateStatus() {
		String output1="Project phase";
		String output2="Deployed in project";
		Associate a=new Associate();
		a.setAssociateName("john");
		assertEquals(output1,a.trackAssociateStatus(45) );
		a.setAssociateName("ram");
		assertEquals(output2,a.trackAssociateStatus(70) );
	    
 	}


}
