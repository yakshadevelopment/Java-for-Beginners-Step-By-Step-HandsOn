package org.junit;

import static org.junit.Assert.assertTrue;



import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

 
import difficult_Hosteller.Hosteller;
import difficult_Hosteller.Main;

class MainTest {

	@Test
	void testGetHostellerDetails() {
		String modify="Y",phone="Y";
		 Hosteller h=new Hosteller();
		// h=Main.getHostellerDetails();
		 h.setStudentId(1);
		
		 h.setName("Rajnikant");
		 h.setDepartmentId(101);
		 h.setGender("Male");
		 h.setPhone("7895246366");
		 h.setHostelName("SNMR");
		 h.setRoomNumber(108);
		 if(modify.equals("Y")) {
			 h.setRoomNumber(110);
		 }
		 if(modify.equals("Y")) {
			 h.setPhone("7709304588");
		 }
		 h=Main.getHostellerDetails();
		  
	 
		assertEquals(true, h instanceof Hosteller );
	}
	
	 
	 

}
