  package com.test;
  import com.java.Numerology;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

class NumerologyTest {

	@Test
	 void testFindValue() {
		 assertEquals(17,  Numerology.findValue("LAKHAN"));
		 assertEquals(-1,  Numerology.findValue("Arti"));
	}

}
